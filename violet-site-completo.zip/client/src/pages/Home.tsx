import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingBag, Zap, Shield, Users } from "lucide-react";

/**
 * Home Page - Landing Page do Violet
 * Design: Minimalismo Moderno com Roxo Vibrante
 * - Hero section com call-to-action
 * - Seções de benefícios com scroll
 * - Botão de login destacado
 */
export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">V</span>
            </div>
            <span className="font-bold text-xl">Violet</span>
          </div>
          <Button
            onClick={() => setLocation("/login")}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            Entrar
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 md:py-32">
        <div className="container max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-purple-500 to-primary bg-clip-text text-transparent">
            Bem-vindo à Violet
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Divulgamos produtos da Shopee com ótimo custo-benefício. Encontre as melhores ofertas em um único lugar.
          </p>
          <Button
            onClick={() => setLocation("/login")}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6"
          >
            Começar Agora
          </Button>
        </div>

        {/* Decorative Background */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-20 right-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl"></div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-card/50">
        <div className="container max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Por que escolher a Violet?
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="p-8 rounded-xl bg-background border border-border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <ShoppingBag className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Melhor Custo-Benefício</h3>
              <p className="text-muted-foreground">
                Selecionamos os melhores produtos da Shopee com os preços mais competitivos do mercado.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-8 rounded-xl bg-background border border-border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Rápido e Fácil</h3>
              <p className="text-muted-foreground">
                Interface intuitiva que facilita a busca e compra dos seus produtos favoritos em segundos.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-8 rounded-xl bg-background border border-border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">100% Seguro</h3>
              <p className="text-muted-foreground">
                Todas as transações são protegidas pela segurança da Shopee. Compre com total confiança.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-8 rounded-xl bg-background border border-border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Comunidade Ativa</h3>
              <p className="text-muted-foreground">
                Faça parte de uma comunidade de compradores inteligentes que buscam as melhores ofertas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4">
        <div className="container max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Como Funciona?
          </h2>

          <div className="space-y-8">
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-lg">
                1
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Crie sua Conta</h3>
                <p className="text-muted-foreground">
                  Faça login rápido e seguro com suas credenciais. Leva menos de 1 minuto!
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-lg">
                2
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Explore Produtos</h3>
                <p className="text-muted-foreground">
                  Navegue por nossas categorias curadas e encontre exatamente o que você procura.
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-lg">
                3
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Compre com Confiança</h3>
                <p className="text-muted-foreground">
                  Adicione ao carrinho e finalize a compra segura através da Shopee.
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-lg">
                4
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Receba em Casa</h3>
                <p className="text-muted-foreground">
                  Acompanhe seu pedido e receba com segurança no conforto da sua casa.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-primary/5">
        <div className="container max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Pronto para começar?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Junte-se a milhares de compradores satisfeitos que já encontraram as melhores ofertas na Violet.
          </p>
          <Button
            onClick={() => setLocation("/login")}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6"
          >
            Fazer Login Agora
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="container max-w-5xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Sobre</h4>
              <p className="text-sm text-muted-foreground">
                Violet é sua plataforma de compras inteligente com os melhores produtos da Shopee.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Links</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Home</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Sobre</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contato</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Privacidade</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Termos</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="https://instagram.com/empresasviolet" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Violet. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
