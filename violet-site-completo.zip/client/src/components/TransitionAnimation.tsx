import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

/**
 * Componente de Animação de Transição Pós-Login
 * Design: Roxo moderno com efeitos visuais sofisticados
 * Duração: ~3 segundos
 */

interface TransitionAnimationProps {
  onComplete?: () => void;
}

export default function TransitionAnimation({ onComplete }: TransitionAnimationProps) {
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimating(false);
      onComplete?.();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isAnimating) return null;

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-violet-900 via-violet-800 to-violet-950 overflow-hidden"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Orbs de fundo animados */}
      <motion.div
        className="absolute w-96 h-96 bg-violet-500 rounded-full blur-3xl opacity-20"
        animate={{
          x: [0, 100, -50, 0],
          y: [0, -100, 50, 0],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        style={{ top: '-10%', left: '-10%' }}
      />
      <motion.div
        className="absolute w-96 h-96 bg-purple-500 rounded-full blur-3xl opacity-20"
        animate={{
          x: [0, -100, 50, 0],
          y: [0, 100, -50, 0],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        style={{ bottom: '-10%', right: '-10%' }}
      />

      {/* Logo/Ícone Violet */}
      <motion.div
        className="relative z-10 flex flex-col items-center gap-6"
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
      >
        {/* Logo V */}
        <motion.div
          className="w-24 h-24 flex items-center justify-center"
          animate={{ rotate: 360 }}
          transition={{ duration: 2, ease: 'easeInOut' }}
        >
          <svg
            viewBox="0 0 100 100"
            className="w-full h-full"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <motion.path
              d="M 20 20 L 50 80 L 80 20"
              stroke="url(#gradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.5, ease: 'easeInOut' }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#a78bfa" />
                <stop offset="100%" stopColor="#7c3aed" />
              </linearGradient>
            </defs>
          </svg>
        </motion.div>

        {/* Texto "Violet" */}
        <motion.h1
          className="text-4xl font-bold text-white tracking-widest"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
        >
          VIOLET
        </motion.h1>

        {/* Linha decorativa */}
        <motion.div
          className="h-1 bg-gradient-to-r from-violet-400 to-purple-400 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: 120 }}
          transition={{ duration: 0.8, delay: 0.5, ease: 'easeOut' }}
        />

        {/* Texto descritivo */}
        <motion.p
          className="text-violet-200 text-center text-sm tracking-wider"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.7, ease: 'easeOut' }}
        >
          Bem-vindo à experiência Violet
        </motion.p>

        {/* Indicador de progresso - 3 pontos animados */}
        <motion.div
          className="flex gap-3 mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1, ease: 'easeOut' }}
        >
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              className="w-3 h-3 rounded-full bg-violet-400"
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: index * 0.2,
              }}
            />
          ))}
        </motion.div>
      </motion.div>

      {/* Partículas flutuantes */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-violet-300 rounded-full opacity-60"
          animate={{
            x: Math.cos((i / 8) * Math.PI * 2) * 200,
            y: Math.sin((i / 8) * Math.PI * 2) * 200,
            opacity: [0.6, 0.2, 0.6],
          }}
          transition={{
            duration: 3,
            ease: 'easeInOut',
            repeat: Infinity,
          }}
          style={{
            left: '50%',
            top: '50%',
            marginLeft: -4,
            marginTop: -4,
          }}
        />
      ))}
    </motion.div>
  );
}
